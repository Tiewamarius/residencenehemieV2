<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package kinsley
 */

get_header();

$layout = get_field( 'blog_featured_img', 'option' );
$blog_single_layout = get_field( 'blog_single_layout', 'option' );

?>

<?php while ( have_posts() ) : the_post(); ?>
<div class="<?php if ( $blog_single_layout ) : ?>knsl-two-blog-single<?php endif; ?>">

	<?php if ( ! $blog_single_layout ) : ?>
	<?php get_template_part( 'template-parts/intro' ); ?>
	<?php endif; ?>

	<?php if ( $blog_single_layout ) : ?>
	<?php get_template_part( 'template-parts/intro-two' ); ?>
	<?php endif; ?>

	<div class="knsl-p-0-100">

		<?php if ( $blog_single_layout ) : ?>
		<?php if ( has_post_thumbnail() && ! $layout ) : $image = get_the_post_thumbnail_url( get_the_ID(), 'kinsley_1920xAuto' ); ?>
		<div class="knsl-two-featured-img">
			<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" class="knsl-default-img knsl-mb-30">
		</div>
		<?php endif; ?>
		<?php endif; ?>

		<div class="container">
			<div class="row justify-content-center<?php if ( ! class_exists( 'ACF' ) ) : ?> row-archive-single<?php endif; ?>">

				<div class="col-lg-8<?php if ( $blog_single_layout ) : ?> col-lg-9<?php endif; ?>">
					
					<?php if ( ! $blog_single_layout ) : ?>
					<?php if ( has_post_thumbnail() && ! $layout ) : $image = get_the_post_thumbnail_url( get_the_ID(), 'kinsley_1920xAuto' ); ?>
					<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" class="knsl-default-img knsl-mb-30">
					<?php endif; ?>
					<?php endif; ?>

					<div class="knsl-blog-post knsl-mb-60">
						<?php get_template_part( 'template-parts/content', 'page' ); ?>
					</div>

					<?php
					if ( comments_open() || get_comments_number() ) :
						// If comments are open or we have at least one comment, load up the comment template.
						comments_template();
					endif; ?>

				</div>

			</div>
		</div>
	</div>

</div>
<?php endwhile; ?>

<?php
get_footer();
